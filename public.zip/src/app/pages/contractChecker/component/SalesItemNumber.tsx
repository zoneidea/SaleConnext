import { KTIcon } from '../../../../_metronic/helpers'
import { Link, useNavigate } from 'react-router-dom'

interface StatusLabelProps {
  status: string;
  item: any
}

const SalesItemNumber: React.FC<StatusLabelProps> = ({ status, item }) => {

  const formatDate = (dateString: any) => {
    const date = new Date(dateString);
    const day = date.getDate();
    const month = date.getMonth();
    const year = date.getFullYear();

    const thaiMonths = [
      "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน",
      "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"
    ];

    return `${day} ${thaiMonths[month]} ${year + 543}`;
  };

  const rawCheckerStatus =
    item?.CHECKKERSTATUS ?? item?.CHECKERSTATUS ?? "";
  const checkerStatusMap: Record<string, string> = {
    PENDING: "รอตรวจสอบ",
    EDIT: "แจ้งแก้ไข",
    APPROVE: "อนุมัติ",
  };
  const checkerStatusText = checkerStatusMap[rawCheckerStatus] ?? "";

  const checkerStatusClass: Record<string, string> = {
    PENDING: "badge badge-light-primary",
    EDIT: "badge badge-light-danger",
    APPROVE: "badge badge-light-success",
  };

  let customer, product, productPackage, serialNumber, createdAt, statusTxt, checkerComment
  if (item.CUSTOMERDETAIL.length > 0) {
    if (item.CUSTOMERDETAIL[0].CUSTOMERTYPE == 1) {
      customer = <span className='text-gray-700 fw-semibold d-block'>{`ชื่อบริษัท: ${item.CUSTOMERDETAIL[0].CUSTOMERMD}`}</span>
    } else {
      customer = <span className='text-gray-700 fw-semibold d-block'>{`ชื่อลูกค้า: ${item.CUSTOMERDETAIL[0].CUSTOMERNAME} ${item.CUSTOMERDETAIL[0].CUSTOMERLASTNAME}`}</span>
    }
  }

  if (item.PRODUCT.length > 0) {
    product = <span className='text-gray-700 fw-semibold d-block'>{`สินค้า: ${item.PRODUCT[0].ItemDescription}`}</span>
    if (item.PRODUCT[0].Package.length > 0) {
      productPackage = <span className='text-gray-700 fw-semibold d-block'>{`แพ็คเกจ: ${item.PRODUCT[0].Package[0].PACKAGETITLE ? item.PRODUCT[0].Package[0].PACKAGETITLE : 'ไม่มีแพ็คเกจ'}`}</span>
      serialNumber = <span className='text-gray-700 fw-semibold d-block'>{`Serial Number: ${item.PRODUCT[0].SerialNo}`}</span>
    }
  }

  if (item.CONTRACT.length > 0) {
    createdAt = <span className='text-gray-700 fw-semibold d-block'>{`วันที่ทำสัญญา: ${item.CONTRACT[0].createdAt && (item.CONTRACT[0].createdAt)}`}</span>
  }

  const teamSaleText = item?.TEAMSALE ? (
    <span className='text-gray-700 fw-semibold d-block'>{`Team Sale: ${item.TEAMSALE}`}</span>
  ) : null;

  return (
    <>
      {
        status === 'DRAFT' ?
          <Link to='/sale/step' state={item} >
            <div className='d-flex align-items-center bg-light-warning rounded p-5 mb-3 col-12'>
              <span className='text-warning me-5'>
                <KTIcon iconName='abstract-26' className='text-warning fs-1 me-5' />
              </span>
              <div className='flex-grow-1 me-2'>
                <div className='fw-bold text-gray-800 text-hover-primary fs-6'>
                  {`เลขที่สัญญา: ${item.CONTNO ?? ""}`}
                </div>
                <div className='fw-bold text-gray-800 text-hover-primary fs-6'>
                  {teamSaleText}
                </div>
                {customer}
                {product}
                {productPackage}
                {serialNumber}
                {createdAt}
                สถานะตรวจสอบ:{" "}
                {checkerStatusText && (
                  <span className={checkerStatusClass[rawCheckerStatus] ?? "badge badge-light"}>
                    {checkerStatusText}
                  </span>
                )}
                {checkerComment}
              </div>
            </div>
          </Link>
          :
          status === 'FINISH' ?
            <div className='d-flex align-items-center bg-light-success rounded p-5 mb-3 col-12'>
              <span className='text-warning me-5'>
                <KTIcon iconName='abstract-26' className='text-warning fs-1 me-5' />
              </span>
              <div className='flex-grow-1 me-2'>
                <div className='fw-bold text-gray-800 text-hover-primary fs-6'>
                  {`เลขที่สัญญา: ${item.CONTNO ?? ""}`}
                </div>
                <div className='fw-bold text-gray-800 text-hover-primary fs-6'>
                  {teamSaleText}
                </div>
                {customer}
                {product}
                {productPackage}
                {serialNumber}
                {createdAt}
                สถานะตรวจสอบ:{" "}
                {checkerStatusText && (
                  <span className={checkerStatusClass[rawCheckerStatus] ?? "badge badge-light"}>
                    {checkerStatusText}
                  </span>
                )}
              </div>
            </div>
            :
            <Link to='/contract-checker/detailChecker' state={item} >
              <div className='d-flex align-items-center bg-light-warning rounded p-5 mb-3 col-12'>
                <span className='text-warning me-5'>
                  <KTIcon iconName='abstract-26' className='text-warning fs-1 me-5' />
                </span>
                <div className='flex-grow-1 me-2'>
                  <div className='fw-bold text-gray-800 text-hover-primary fs-6'>
                    {`เลขที่สัญญา: ${item.CONTNO ?? ""}`}
                  </div>
                  <div className='fw-bold text-gray-800 text-hover-primary fs-6'>
                    {teamSaleText}
                  </div>
                  {customer}
                  {product}
                  {productPackage}
                  {serialNumber}
                  {createdAt}
                  สถานะตรวจสอบ:{" "}
                  {checkerStatusText && (
                    <span className={checkerStatusClass[rawCheckerStatus] ?? "badge badge-light"}>
                      {checkerStatusText}
                    </span>
                  )}
                </div>
              </div>
            </Link>
      }
    </>
  )
}

export { SalesItemNumber }