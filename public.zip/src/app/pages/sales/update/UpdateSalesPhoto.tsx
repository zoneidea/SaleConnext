import styles from "@/styles/style.module.css";
import { useState, useMemo, useEffect } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { KTIcon, toAbsoluteUrl } from "../../../../_metronic/helpers";
import { Content } from "../../../../_metronic/layout/components/content";
import axios from "axios";
import { useAuth } from "../../../modules/auth/core/Auth";
import { useUUIDStore } from "../../../modules/stores/stepsStore";

import Swal from "sweetalert2";
import withReactContent from "sweetalert2-react-content";

import { ThreeDot } from "react-loading-indicators";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { log } from "node:console";

// อัพเดท
interface ItemProps {
    REFNO: string;
    CONTNO: string;
    EMPID: string;
    TEAMSALE: string;
    SALECODE: string;
    SUPEMPID: string;
    SECEMPID: string;
    STATUS: string;
    PRODUCT: [any];
    CUSTOMERSTATUS: [any];
    DISCOUNT: [any];
    CUSTOMERDETAIL: [any];
    ADDRESS: [any];
    PDPA: [any];
    CONTRACT: [any];
    IMAGE: [any];
    CHECKERCOMMENT: [any];
}

interface ImagesType {
    IMAGECARD: string[];
    IMAGEGPS: string[];
    IMAGEMAP: string[];
    IMAGECUSTOMERHOME: string[];
    IMAGEINSTALLATION: string[];
    IMAGETDS: string[];
    IMAGECUSTOMER: string[];
    IMAGETRADEIN: string[];
}

const UpdateSalesPhoto: React.FC = () => {
    const navigate = useNavigate();
    const MySwal = withReactContent(Swal);

    // สร้างใหม่
    const { REFNO } = useUUIDStore();
    const { auth } = useAuth();
    const EmpId = auth?.data?.[0]?.EmpId || "";
    const TeamSale = auth?.data?.[0]?.TeamSale || "";
    const SaleCode = auth?.data?.[0]?.SaleCode || "";
    const SupEmpId = auth?.data?.[0]?.SupEmp || "";
    const SecEmpId = auth?.data?.[0]?.SecEmp || "";

    const location = useLocation() as any;
    const fromStep = location.state?.fromStep || false;
    // console.log(`fromStep`, fromStep);
    const fromPath = location.state?.from || '';
    const item = (location.state?.data as ItemProps) || [];
    // console.log(`item`, item);

    const hideFinish = fromPath === '/sale/editFinishInDay' ||
        '/sale/photo/gallery/drawingMap' ||
        '/sale/photo/gallery/idcard' ||
        '/sale/photo/gallery/customer' ||
        '/sale/photo/gallery/customerHome' ||
        '/sale/photo/gallery/equipment' ||
        '/sale/photo/gallery/installation' ||
        '/sale/photo/gallery/turn' ||
        '/sale/photo/gallery-gps'

    // console.log(`hideFinish`, hideFinish);

    // กำหนด REFNO
    const refno = fromStep ? item.REFNO : REFNO;
    // console.log(`refno`, refno);

    const [images, setImages] = useState<ImagesType | null>(null);
    // console.log(`images`, images);

    const [isLoading, setIsLoading] = useState(true);

    const API_URL_MONGO = import.meta.env.VITE_APP_API_MONGO;
    const UPDATECONTACT = `${API_URL_MONGO}/Contract/updateContract`;
    const DRAFT_ALLCONTRACT_URL = `${API_URL_MONGO}/Contract/GetAllContract?status=DRAFT&empid=${EmpId}&teamsale=${TeamSale}&salecode=${SaleCode}&ProcessType=${auth.processtype}`;
    // const GET_IMAGES_API = `${API_URL_MONGO}/Contract/GetContractImage?REFNO=${refno}`;

    const API_URL_SALECONNEXT = import.meta.env.VITE_APP_API_SALECONNEXT;
    const GET_IMAGES_API = `${API_URL_SALECONNEXT}/GetContractImages?RefNo=${refno}&EmpId=${EmpId}`;
    {
        /****** matchedItem *******/
    }
    const [isLoadingDraft, setIsLoadingDraft] = useState<boolean>(false);
    const [draft, setDraft] = useState<any[]>([]);

    useEffect(() => {
        const getDataDraft = async () => {
            setIsLoadingDraft(true);
            try {
                const response = await axios.get(DRAFT_ALLCONTRACT_URL);
                const data = Array.isArray(response.data.data)
                    ? response.data.data
                    : [];
                setDraft(data);
            } catch (error) {
                console.error("Error fetching DRAFT_ALLCONTRACT_URL:", error);
            } finally {
                setIsLoadingDraft(false);
            }
        };
        getDataDraft();
    }, []);

    // เลือก item ที่ REFNO ตรงกัน (find สำหรับ 1 item หรือ filter สำหรับหลาย item)
    // const matchedItem = draft.find((item) => item.REFNO === item.REFNO);
    const matchedItem = draft.find((d) => d.REFNO === refno);
    // console.log(`matchedItem`, matchedItem);

    // fetch collection ContractImage
    // useEffect(() => {
    //     const fetchImages = async () => {
    //         try {
    //             const response = await axios.get(GET_IMAGES_API);

    //             // ตรวจสอบว่า response.data เป็นไปตามโครงสร้างของ ImagesType
    //             const data = response.data;

    //             if (
    //                 data &&
    //                 typeof data === "object" &&
    //                 "IMAGECARD" in data &&
    //                 "IMAGEGPS" in data &&
    //                 "IMAGEMAP" in data &&
    //                 "IMAGECUSTOMERHOME" in data &&
    //                 "IMAGEINSTALLATION" in data &&
    //                 "IMAGETDS" in data &&
    //                 "IMAGETRADEIN" in data
    //             ) {
    //                 setImages(data as ImagesType);
    //             } else {
    //                 setImages(null);
    //             }
    //         } catch (err) {
    //             console.error("Error fetching images:", err);
    //             setImages(null); // ตั้งค่าเป็น null หากมีข้อผิดพลาด
    //         }
    //     };

    //     fetchImages();
    // }, [refno]);


    useEffect(() => {
        const fetchImages = async () => {
            try {
                const resp = await axios.get(GET_IMAGES_API);
                const groups = Array.isArray(resp.data?.data) ? resp.data.data : [];

                // เตรียม object ตาม ImagesType เดิม
                const nextImages: ImagesType = {
                    IMAGECARD: [],
                    IMAGEGPS: [],
                    IMAGEMAP: [],
                    IMAGECUSTOMERHOME: [],
                    IMAGEINSTALLATION: [],
                    IMAGETDS: [],
                    IMAGECUSTOMER: [],     // จะใช้เก็บ TRANSFERSLIP
                    IMAGETRADEIN: [],      // จะใช้เก็บ CUSTOMER (เครื่องเทิร์น)
                };

                // helper: ดึง URL จากแต่ละรายการรูป
                const pickUrls = (arr: any[]) =>
                    (Array.isArray(arr) ? arr : [])
                        .map((it: any) => it?.FULLURL || it?.FULLPATH || "")
                        .filter(Boolean);

                // แม็พ IMAGETYPECODE → ช่องใน state
                for (const g of groups) {
                    const code = g?.IMAGETYPECODE;
                    const urls = pickUrls(g?.IMAGES);

                    switch (code) {
                        case "MAP":
                            nextImages.IMAGEGPS = urls;
                            break;
                        case "IDCARD":
                            nextImages.IMAGECARD = urls;
                            break;
                        case "TDS":
                            nextImages.IMAGETDS = urls;
                            break;
                        case "PAYMENTCARD":
                            nextImages.IMAGEMAP = urls; // รูปวาดแผนที่
                            break;
                        case "ADDRESS":
                            nextImages.IMAGECUSTOMERHOME = urls;
                            break;
                        case "INSTALLATION":
                            nextImages.IMAGEINSTALLATION = urls;
                            break;
                        case "TRADEINPRODUCT":
                            nextImages.IMAGETRADEIN = urls; // รูปเครื่องเทิร์น
                            break;
                        case "TRANSFERSLIP":
                            nextImages.IMAGECUSTOMER = urls; // สลิปโอนเงิน
                            break;
                        default:
                            break;
                    }
                }

                setImages(nextImages);
            } catch (err) {
                console.error("Error fetching images:", err);
                setImages(null);
            }
        };

        fetchImages();
    }, [GET_IMAGES_API, refno, EmpId]);

    // โหลดก่อน 2 วิจึงโชว์ ui ทั้งหน้า
    useEffect(() => {
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 2000); // แสดง ThreeDot เป็นเวลา 2 วินาที

        return () => clearTimeout(timer); // เคลียร์ timer เมื่อ component ถูก unmount
    }, []);

    // ฟังก์ชัน ส่งตรวจสอบ (กรณีไม่ได้มาจาก step)
    const handleCheckerClick = async () => {
        const missing = getIncompleteStep();

        if (missing) {
            MySwal.fire({
                icon: "warning",
                title: "ข้อมูลยังไม่ครบ",
                text: `กรุณากรอกข้อมูลขั้นตอนที่ ${missing}`,
            });
            return;
        }

        MySwal.fire({
            title: "โปรดรอสักครู่...",
            text: "กำลังส่งข้อมูล",
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            },
        });

        const finishRefno = refno ? refno : matchedItem?.REFNO;

        try {
            const response = await axios.post(
                UPDATECONTACT,
                {
                    REFNO: finishRefno,
                    EMPID: EmpId,
                    TEAMSALE: TeamSale,
                    SALECODE: SaleCode,
                    SUPEMPID: SupEmpId,
                    SECEMPID: SecEmpId,
                    FIELD: "STATUS",
                    DATA: "FINISH",
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            );

            const responseData = response.data;
            const innerData = responseData?.data;
            const innerStatus = String(innerData?.status || "").toLowerCase();

            const isSaveSuccess =
                response.status === 200 &&
                innerData &&
                innerStatus !== "error" &&
                innerStatus !== "fail" &&
                innerStatus !== "failed" &&
                innerStatus !== "false";

            if (!isSaveSuccess) {
                await MySwal.fire(
                    "บันทึกไม่สำเร็จ",
                    innerData?.message ||
                    responseData?.message ||
                    "ส่งข้อมูลไม่สำเร็จ กรุณาติดต่อผู้พัฒนา",
                    "error"
                );
                return;
            }

            await MySwal.fire({
                icon: "success",
                title: "สำเร็จ!",
                text: "บันทึกสัญญาเรียบร้อยแล้ว",
                timer: 2000,
                showConfirmButton: false,
            });

            navigate("/sale/overview");
        } catch (error: any) {
            console.error("Error UPDATECONTACT:", error);

            await MySwal.fire(
                "เกิดข้อผิดพลาด",
                error?.response?.data?.data?.message ||
                error?.response?.data?.message ||
                error?.message ||
                "ส่งข้อมูลไม่สำเร็จ กรุณาติดต่อผู้พัฒนา",
                "error"
            );
        }
    };

    // ฟังก์ชัน ส่งตรวจสอบ (กรณีมาจาก step)
    const handleUpdateCheckerClick = async () => {
        const missing = getIncompleteStep();

        if (missing) {
            MySwal.fire({
                icon: "warning",
                title: "ข้อมูลยังไม่ครบ",
                text: `กรุณากรอกข้อมูลขั้นตอนที่ ${missing}`,
            });
            return;
        }

        MySwal.fire({
            title: "โปรดรอสักครู่...",
            text: "กำลังส่งข้อมูล",
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            },
        });

        try {
            const response = await axios.post(
                UPDATECONTACT,
                {
                    REFNO: refno,
                    EMPID: EmpId,
                    TEAMSALE: TeamSale,
                    FIELD: "STATUS",
                    DATA: "FINISH",
                },
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            );

            const responseData = response.data;
            const innerData = responseData?.data;
            const innerStatus = String(innerData?.status || "").toLowerCase();

            const isSaveSuccess =
                response.status === 200 &&
                innerData &&
                innerStatus !== "error" &&
                innerStatus !== "fail" &&
                innerStatus !== "failed" &&
                innerStatus !== "false";

            if (!isSaveSuccess) {
                await MySwal.fire(
                    "บันทึกไม่สำเร็จ",
                    innerData?.message ||
                    responseData?.message ||
                    "ส่งข้อมูลไม่สำเร็จ กรุณาติดต่อผู้พัฒนา",
                    "error"
                );
                return;
            }

            await MySwal.fire({
                icon: "success",
                title: "สำเร็จ!",
                text: "ส่งข้อมูลตรวจสอบแล้ว",
                timer: 2000,
                showConfirmButton: false,
            });

            navigate("/sale/overview");
        } catch (error: any) {
            console.error("Error UPDATECONTACT:", error);

            await MySwal.fire(
                "เกิดข้อผิดพลาด",
                error?.response?.data?.data?.message ||
                error?.response?.data?.message ||
                error?.message ||
                "ไม่สามารถส่งข้อมูลได้",
                "error"
            );
        }
    };

    const isNonEmptyStr = (v: any) => typeof v === 'string' && v.trim() !== ''

    const hasAny = <T,>(arr: T[], pred: (x: T) => boolean) =>
        Array.isArray(arr) && arr.some(pred)

    const stepsCheck = useMemo(() => {
        const source = fromStep ? item : matchedItem;
        if (!source) {
            return {
                okCustomerStatus: false,
                okProduct: false,
                okDiscount: false,
                okSaleEmp: false,
                okCustDetail: false,
                okAddress: false,
                okPdpa: false,
                okContract: false,
            };
        }

        const okCustomerStatus = hasAny(source.CUSTOMERSTATUS, (o: any) =>
            isNonEmptyStr(o.CustomerName) ||
            isNonEmptyStr(o.message) ||
            isNonEmptyStr(o.Message) ||
            isNonEmptyStr(o.Searchtext)
        );

        const okProduct = hasAny(source.PRODUCT, (p: any) =>
            isNonEmptyStr(p.ItemDescription) ||
            isNonEmptyStr(p.ItemCode) ||
            (Array.isArray(p.Package) && p.Package.length > 0)
        );

        const okDiscount = hasAny(source.DISCOUNT, (d: any) =>
            d?.DISCOUNTAMOUNT != null ||
            isNonEmptyStr(d?.GIFT?.GIFTDESCRIPTION) ||
            isNonEmptyStr(d?.TRADEIN?.TRADEINMODEL) ||
            d?.TRADEIN?.HASTRADEIN === 1
        );

        const okSaleEmp = hasAny(source.SALEEMPLOYEE, (s: any) =>
            !!s?.SALEEMPLOYEE &&
            (
                isNonEmptyStr(s.SALEEMPLOYEE.FName) ||
                isNonEmptyStr(s.SALEEMPLOYEE.SaleEmp) ||
                isNonEmptyStr(s.SALEEMPLOYEE.EmpId)
            )
        );

        const cd = source.CUSTOMERDETAIL?.[0] ?? {};
        const okCustDetail =
            !!cd?.CUSTOMERTYPE ||
            isNonEmptyStr(cd?.CUSTOMERNAME) ||
            isNonEmptyStr(cd?.CUSTOMERMOBILE) ||
            (Array.isArray(cd?.PREFIX) && cd.PREFIX.length > 0);

        const okAddress = hasAny(source.ADDRESS, (a: any) => {
            const c = a?.ADDRESSCARD ?? a?.ADDRESSINSTALLATION ?? a?.ADDRESSPAYMENT;
            return isNonEmptyStr(c?.ADDRESSPROVINCENAME) || isNonEmptyStr(c?.ADDRESSZIPCODE);
        });

        const okPdpa = hasAny(source.PDPA, (p: any) => typeof p?.CONSENTGIVEN === "boolean");

        const okContract = hasAny(source.CONTRACT, (c: any) =>
            isNonEmptyStr(c?.createdAt) || isNonEmptyStr(c?.CONTNO)
        );

        return {
            okCustomerStatus,
            okProduct,
            okDiscount,
            okSaleEmp,
            okCustDetail,
            okAddress,
            okPdpa,
            okContract,
        };
    }, [fromStep, item, matchedItem]);

    const getIncompleteStep = () => {
        const mapping: Record<string, string> = {
            okCustomerStatus: "1. ตรวจสอบสถานะลูกค้า",
            okProduct: "2. เลือกแพ็คเกจ",
            okDiscount: "3. ส่วนลด / เครื่องเทิร์น / ของแถม",
            okSaleEmp: "4. เลือกพนักงานขาย",
            okCustDetail: "5. บันทึกข้อมูลลูกค้า",
            okAddress: "6. บันทึกที่อยู่ลูกค้า",
            okPdpa: "7. PDPA",
            okContract: "8. รายละเอียดสัญญา",
        };

        for (const key of Object.keys(stepsCheck)) {
            if (!stepsCheck[key as keyof typeof stepsCheck]) {
                return mapping[key];
            }
        }

        return null; // ครบทุกขั้นตอน
    };

    const whereRefno = fromStep ? refno : matchedItem?.REFNO ?? "";

    return (
        <>
            {isLoading ? (
                <div className="text-center my-10">
                    <ThreeDot />
                </div>
            ) : (
                <Content>
                    <div className="d-flex justify-content-between align-items-center my-5">
                        <div
                            id="kt_page_title"
                            data-kt-swapper="true"
                            data-kt-swapper-mode="prepend"
                            data-kt-swapper-parent="{default: '#kt_content_container', 'lg': '#kt_toolbar_container'}"
                            className="page-title d-flex flex-wrap me-3 flex-column justify-content-center"
                        >
                            <div className={`breadcrumb-item ${styles.titlePage}`}>
                                <span>ถ่ายรูป</span>
                            </div>
                        </div>
                    </div>
                    <span className={`${styles.fontSize}`}>เลขที่ขาย: {""}</span>
                    <span className={`${styles.titlePage}`}>
                        {whereRefno ? whereRefno : item?.REFNO}
                    </span>

                    <div className="row gx-4 gy-6 mb-20">
                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGEGPS.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery-gps", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปแผนที่ GPS
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl(
                                        "media/take-a-pic/map-gps-svgrepo-com.svg"
                                    )}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGECARD.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/idcard", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปบัตรประชาชน
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl("media/take-a-pic/id-card-pass.svg")}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGETDS.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/equipment", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปอุปกรณ์วัดค่าน้ำ
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl(
                                        "media/take-a-pic/water-water-svgrepo-com.svg"
                                    )}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGEMAP.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/drawingMap", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปวาดแผนที่
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl("media/take-a-pic/map-svgrepo-com.svg")}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGECUSTOMERHOME.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/customerHome", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปบ้านลูกค้า
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl(
                                        "media/take-a-pic/home-house-svgrepo-com.svg"
                                    )}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGEINSTALLATION.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/installation", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปติดตั้งเครื่อง/ลูกค้า
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl(
                                        "media/take-a-pic/setting-configuration-gear-svgrepo-com.svg"
                                    )}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGETRADEIN.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/turn", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            รูปเครื่องเทิร์นหรือโปรโมชั่น
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl("media/take-a-pic/water-svgrepo-com.svg")}
                                    alt=""
                                />
                            </button>
                        </div>
                        {/* End Card Body */}

                        {/* Card Body */}
                        <div className="card col-lg-3 col-6">
                            {images?.IMAGECUSTOMER.length! > 0 && (
                                <span className="position-absolute bottom-0 end-0 m-2 fs-6">
                                    <img
                                        className="mx-auto h-40px theme-light-show"
                                        src={toAbsoluteUrl(
                                            "media/take-a-pic/circle-check-solid-full.svg"
                                        )}
                                    />
                                </span>
                            )}
                            <button
                                style={{
                                    background: "none",
                                    border: "none",
                                    padding: 0,
                                    color: "inherit",
                                    cursor: "pointer",
                                    fontSize: "inherit",
                                }}
                                onClick={() =>
                                    navigate("/sale/photo/gallery/transferslip", {
                                        state: { fromStep, data: item },
                                    })
                                }
                            >
                                <div className="mb-10 mt-7">
                                    <div className="text-gray-800 text-center">
                                        <span
                                            className={`position-relative d-inline-block text-dangeropacity-75-hover ${styles.fontSize}`}
                                        >
                                            สลิปโอนเงิน (ถ้ามี)
                                        </span>
                                    </div>
                                </div>
                                <img
                                    className="mx-auto h-100px h-lg-150px theme-light-show"
                                    src={toAbsoluteUrl(
                                        "media/take-a-pic/person-boy-svgrepo-com.svg"
                                    )}
                                    alt=""
                                />
                            </button>
                        </div>
                    </div>
                    {/* End Card Body */}

                    {/* แสดงปุ่มเมื่อมาจาก Step */}
                    <div className="d-none d-xl-flex justify-content-start align-items-center mt-5 mb-10">
                        <div
                            className="ms-auto"
                        >
                            <button
                                className={`${styles.btnPrimary}`}
                                onClick={handleCheckerClick}
                            >
                                จบการทำงาน
                            </button>
                        </div>
                    </div>

                    {/* ปุ่มในหน้าจอเล็ก */}
                    {/* แสดงปุ่มเมื่อมาจาก Step */}
                    <div
                        className="d-flex d-xl-none justify-content-start align-items-center bg-light p-3 border-top"
                        style={{
                            position: "fixed",
                            bottom: 0,
                            left: 0,
                            right: 0,
                            zIndex: 1050,
                        }}
                    >
                        <div
                            className="ms-auto"
                        >
                            <button
                                className={`${styles.btnPrimary}`}
                                onClick={handleCheckerClick}
                            >
                                จบการทำงาน
                            </button>
                        </div>
                    </div>
                </Content>
            )}
        </>
    );
};

export default UpdateSalesPhoto;
