import React, { useState, useEffect, useRef } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import { useLocation, useNavigate } from 'react-router-dom';
import html2canvas from 'html2canvas';
import { useUUIDStore } from '../../../../../modules/stores/stepsStore';
import axios from 'axios';
import Swal from 'sweetalert2';
import styles from '@/styles/style.module.css';

const API_KEY_GOOGLE_MAP = import.meta.env.VITE_APP_GOOGLE_MAP_KEY as string;
const API_URL_MONGO = import.meta.env.VITE_APP_API_MONGO;

interface ItemProps {
  REFNO: string;
  CONTNO: string;
  EMPID: string;
  TEAMSALE: string;
  SALECODE: string;
  SUPEMPID: string;
  SECEMPID: string;
  STATUS: string;
  PRODUCT: [any];
  CUSTOMERSTATUS: [any];
  DISCOUNT: [any];
  CUSTOMERDETAIL: [any];
  ADDRESS: [any];
  PDPA: [any];
  CONTRACT: [any];
  IMAGE: [any];
  CHECKERCOMMENT: [any];
}

interface Position {
  latitude: number | null;
  longitude: number | null;
}

const containerStyle: React.CSSProperties = {
  width: '100%',
  height: '100vh',
};

const WEBP_QUALITY = 0.78;

const LocationFinder: React.FC = () => {
  const [position, setPosition] = useState<Position>({
    latitude: null,
    longitude: null,
  });

  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { REFNO } = useUUIDStore();
  const location = useLocation() as any;

  const item = (location.state?.data as ItemProps) || {};
  const fromStep = location.state?.fromStep || false;
  const refno = fromStep ? item.REFNO : REFNO;

  const getCurrentLocation = () => {
    if (!navigator.geolocation) {
      setError('เบราว์เซอร์ของคุณไม่รองรับการค้นหาตำแหน่งที่ตั้ง');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setPosition({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
        });
        setError(null);
      },
      (err) => {
        switch (err.code) {
          case err.PERMISSION_DENIED:
            setError('ผู้ใช้ปฏิเสธการเข้าถึงตำแหน่งที่ตั้ง');
            break;
          case err.POSITION_UNAVAILABLE:
            setError('ข้อมูลตำแหน่งที่ตั้งไม่พร้อมใช้งาน');
            break;
          case err.TIMEOUT:
            setError('การร้องขอตำแหน่งเกินเวลาที่กำหนด');
            break;
          default:
            setError('เกิดข้อผิดพลาดในการดึงตำแหน่งที่ตั้ง');
        }
      },
      {
        enableHighAccuracy: true,
        timeout: 15000,
        maximumAge: 0,
      }
    );
  };

  useEffect(() => {
    getCurrentLocation();
  }, []);

  return (
    <div>
      {error ? (
        <p style={{ color: 'red' }}>{error}</p>
      ) : position.latitude && position.longitude ? (
        <GoogleMapComponent
          position={position}
          REFNO={refno}
          fromStep={fromStep}
          item={item}
        />
      ) : (
        <p>กำลังดึงตำแหน่ง...</p>
      )}
    </div>
  );
};

const GoogleMapComponent: React.FC<{
  position: Position;
  REFNO?: string;
  fromStep?: boolean;
  item: ItemProps;
}> = ({ position, REFNO, fromStep, item }) => {
  const navigate = useNavigate();
  const mapRef = useRef<HTMLDivElement>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const canvasToWebPFile = (
    canvas: HTMLCanvasElement,
    fileName: string,
    quality = WEBP_QUALITY
  ): Promise<File> => {
    return new Promise((resolve, reject) => {
      canvas.toBlob(
        (blob) => {
          if (!blob) {
            reject(new Error('ไม่สามารถแปลงรูปเป็น WebP ได้'));
            return;
          }

          const file = new File([blob], fileName, {
            type: 'image/webp',
            lastModified: Date.now(),
          });

          resolve(file);
        },
        'image/webp',
        quality
      );
    });
  };

  const captureMap = async () => {
    if (!mapRef.current) return;

    try {
      setIsLoading(true);

      const canvas = await html2canvas(mapRef.current, {
        useCORS: true,
        backgroundColor: '#ffffff',
        scale: 1,
        logging: false,
      });

      const ts = new Date().toISOString().replace(/[:.]/g, '-');
      const uid =
        crypto?.randomUUID?.() ?? Math.random().toString(36).slice(2, 10);

      const uniqueName = `gps_${REFNO ?? 'ref'}_${ts}_${uid}.webp`;

      const file = await canvasToWebPFile(canvas, uniqueName, WEBP_QUALITY);

      const formData = new FormData();

      if (REFNO) {
        formData.append('REFNO', REFNO);
      }

      formData.append('IMAGEGPS', file, uniqueName);
      formData.append('LATITUDE', `${position.latitude ?? ''}`);
      formData.append('LONGITUDE', `${position.longitude ?? ''}`);

      await handleNextClick(formData);
    } catch (error) {
      console.error('เกิดข้อผิดพลาดในการสร้างภาพแผนที่:', error);

      Swal.fire({
        icon: 'error',
        title: 'เกิดข้อผิดพลาด!',
        text: 'ไม่สามารถสร้างรูปภาพแผนที่ได้ กรุณาลองใหม่อีกครั้ง',
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleNextClick = async (formData: FormData) => {
    try {
      await axios.post(
        `${API_URL_MONGO}/Contract/SaveContractImage`,
        formData,
        {
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        }
      );

      Swal.fire({
        icon: 'success',
        title: 'สำเร็จ!',
        text: 'บันทึกรูปภาพแผนที่ลงระบบเรียบร้อยแล้ว',
        timer: 2000,
        showConfirmButton: false,
      });

      navigate('/sale/photo/gallery-gps', {
        state: { fromStep, data: item },
      });
    } catch (error) {
      console.error('Error uploading map image:', error);

      Swal.fire({
        icon: 'error',
        title: 'เกิดข้อผิดพลาด!',
        text: 'ไม่สามารถบันทึกรูปภาพได้ กรุณาลองใหม่อีกครั้ง',
      });
    }
  };

  const center = {
    lat: position.latitude ?? 0,
    lng: position.longitude ?? 0,
  };

  return (
    <>
      <LoadScript googleMapsApiKey={API_KEY_GOOGLE_MAP}>
        <div ref={mapRef} style={containerStyle}>
          <GoogleMap
            mapContainerStyle={containerStyle}
            center={center}
            zoom={17}
          >
            <Marker position={center} title="ตำแหน่งปัจจุบัน" />
          </GoogleMap>
        </div>
      </LoadScript>

      {!isLoading && (
        <div className="d-none d-xl-flex justify-content-between align-items-center my-5 mx-7">
          <button
            className={`${styles.btnSecondary}`}
            onClick={() =>
              navigate('/sale/photo/gallery-gps', {
                state: { data: item, fromStep },
              })
            }
          >
            ย้อนกลับ
          </button>

          <button onClick={captureMap} className={`${styles.btnPrimary}`}>
            บันทึกรูปภาพแผนที่ลงระบบ
          </button>
        </div>
      )}

      {!isLoading && (
        <div
          className="d-flex d-xl-none justify-content-between align-items-center bg-light p-3 border-top"
          style={{
            position: 'fixed',
            bottom: 0,
            left: 0,
            right: 0,
            zIndex: 1050,
          }}
        >
          <button
            className={`${styles.btnSecondary}`}
            onClick={() =>
              navigate('/sale/photo/gallery-gps', {
                state: { data: item, fromStep },
              })
            }
          >
            ย้อนกลับ
          </button>

          <button className={`${styles.btnPrimary}`} onClick={captureMap}>
            บันทึกรูปภาพแผนที่ลงระบบ
          </button>
        </div>
      )}

      {isLoading && (
        <div
          className="d-flex justify-content-center align-items-center bg-light p-3 border-top"
          style={{
            position: 'fixed',
            bottom: 0,
            left: 0,
            right: 0,
            zIndex: 1050,
          }}
        >
          กำลังบันทึกรูปภาพแผนที่...
        </div>
      )}
    </>
  );
};

export default LocationFinder;